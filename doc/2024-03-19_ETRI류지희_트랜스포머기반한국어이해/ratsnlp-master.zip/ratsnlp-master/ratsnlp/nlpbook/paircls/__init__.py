from .corpus import *
from .deploy import get_web_service_app

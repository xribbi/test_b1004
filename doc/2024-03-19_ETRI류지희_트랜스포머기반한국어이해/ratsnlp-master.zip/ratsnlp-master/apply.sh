git config --local commit.template .gitmessage.txt
